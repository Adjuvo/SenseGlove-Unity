var searchData=
[
  ['_5fgrabreference_0',['_grabReference',['../class_s_g_1_1_s_g___dial.html#a3e37d339b417234d3098758400a2572f',1,'SG::SG_Dial']]],
  ['_5fgrabscript_1',['_grabScript',['../class_s_g_1_1_s_g___interactable.html#ab6ca31cd19cdf3d45ff2488b76b6cdfc',1,'SG::SG_Interactable']]]
];
