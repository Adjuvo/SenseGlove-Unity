var searchData=
[
  ['qbase_1321',['qBase',['../class_s_g_1_1_s_g___dial.html#ad1c0dffbda873a71e56948f72242cfbc',1,'SG::SG_Dial']]]
];
