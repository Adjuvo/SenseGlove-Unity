var searchData=
[
  ['newdata_387',['newData',['../class_s_g_1_1_s_g___sense_glove_hardware_1_1_glove_calibration_args.html#a3a0dbbb1757e15e9779dde952c97a985',1,'SG::SG_SenseGloveHardware::GloveCalibrationArgs']]],
  ['nextglove_388',['NextGlove',['../class_s_g_1_1_s_g___sense_glove_hardware.html#aa221bf717f785096ea68745912b13346aa30cf538df4023508febdb94d933d023',1,'SG::SG_SenseGloveHardware']]],
  ['nextlefthand_389',['NextLeftHand',['../class_s_g_1_1_s_g___sense_glove_hardware.html#aa221bf717f785096ea68745912b13346a258c6013dff8ee36943f1da00788e091',1,'SG::SG_SenseGloveHardware']]],
  ['nextrighthand_390',['NextRightHand',['../class_s_g_1_1_s_g___sense_glove_hardware.html#aa221bf717f785096ea68745912b13346abf13f068723737fcc8e3136676aa01e7',1,'SG::SG_SenseGloveHardware']]],
  ['nextstepkey_391',['nextStepKey',['../class_s_g_1_1_calibration_1_1_s_g___calibration_sequence.html#a2949e95f58a89b2b1cd0da09fde41341',1,'SG::Calibration::SG_CalibrationSequence']]],
  ['none_392',['None',['../class_s_g_1_1_s_g___breakable.html#a8750c60bd4c02823169c8886a90a6dfea6adf97f83acf6453d4a6a4b1070f3754',1,'SG::SG_Breakable']]],
  ['normalizeangle_393',['NormalizeAngle',['../class_s_g_1_1_s_g___util.html#a8ff93bc4b355121e2605db016036d6bf',1,'SG.SG_Util.NormalizeAngle(float angle)'],['../class_s_g_1_1_s_g___util.html#a9ee99d112549ed10bb0e8479b16354a5',1,'SG.SG_Util.NormalizeAngle(float angle, float minAngle, float maxAngle)']]],
  ['normalizeangles_394',['NormalizeAngles',['../class_s_g_1_1_s_g___util.html#a3b90fc9f802dc72ed417140edb817ca7',1,'SG::SG_Util']]],
  ['numberofobjects_395',['NumberOfObjects',['../class_s_g_1_1_s_g___drop_zone.html#ae5434d3dc7c383fce392db2eb9873330',1,'SG::SG_DropZone']]],
  ['numberofsensors_396',['numberOfSensors',['../class_s_g_1_1_s_g___sense_glove_data.html#a1ed26af6f66fd343f13fd504a4f391ee',1,'SG::SG_SenseGloveData']]]
];
