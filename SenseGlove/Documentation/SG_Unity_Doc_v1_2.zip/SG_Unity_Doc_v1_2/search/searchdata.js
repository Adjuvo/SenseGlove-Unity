var indexSectionsWithContent =
{
  0: "_abcdefghijlmnopqrstuvwxyz",
  1: "bcdfgms",
  2: "s",
  3: "abcdefghilmnoprstuvwz",
  4: "_abcdefghijlmnopqrstuvwxy",
  5: "acdgmrstuv",
  6: "cdeflmnoprsuv",
  7: "acdefghinorstuw",
  8: "cdgimotu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events"
};

