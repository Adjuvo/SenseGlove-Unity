var searchData=
[
  ['normalizeangle_957',['NormalizeAngle',['../class_s_g_1_1_s_g___util.html#a8ff93bc4b355121e2605db016036d6bf',1,'SG.SG_Util.NormalizeAngle(float angle)'],['../class_s_g_1_1_s_g___util.html#a9ee99d112549ed10bb0e8479b16354a5',1,'SG.SG_Util.NormalizeAngle(float angle, float minAngle, float maxAngle)']]],
  ['normalizeangles_958',['NormalizeAngles',['../class_s_g_1_1_s_g___util.html#a3b90fc9f802dc72ed417140edb817ca7',1,'SG::SG_Util']]]
];
