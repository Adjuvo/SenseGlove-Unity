var searchData=
[
  ['objectsinside_1474',['ObjectsInside',['../class_s_g_1_1_s_g___drop_zone.html#a6ee72b0b89f94cbe9fdb8792f08cab5e',1,'SG::SG_DropZone']]],
  ['originalparent_1475',['OriginalParent',['../class_s_g_1_1_s_g___grabable.html#a3dadc7664a5b9365371c2f049762956a',1,'SG::SG_Grabable']]]
];
