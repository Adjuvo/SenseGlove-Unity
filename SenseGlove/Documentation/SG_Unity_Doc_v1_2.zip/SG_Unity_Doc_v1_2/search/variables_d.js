var searchData=
[
  ['newdata_1289',['newData',['../class_s_g_1_1_s_g___sense_glove_hardware_1_1_glove_calibration_args.html#a3a0dbbb1757e15e9779dde952c97a985',1,'SG::SG_SenseGloveHardware::GloveCalibrationArgs']]],
  ['nextstepkey_1290',['nextStepKey',['../class_s_g_1_1_calibration_1_1_s_g___calibration_sequence.html#a2949e95f58a89b2b1cd0da09fde41341',1,'SG::Calibration::SG_CalibrationSequence']]],
  ['numberofsensors_1291',['numberOfSensors',['../class_s_g_1_1_s_g___sense_glove_data.html#a1ed26af6f66fd343f13fd504a4f391ee',1,'SG::SG_SenseGloveData']]]
];
