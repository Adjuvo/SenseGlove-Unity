var searchData=
[
  ['smoothedvelocity_1477',['SmoothedVelocity',['../class_s_g_1_1_s_g___basic_feedback.html#ac8dabee32ca704299681ef875b67500f',1,'SG::SG_BasicFeedback']]],
  ['startjointpositions_1478',['StartJointPositions',['../class_s_g_1_1_s_g___sense_glove_hardware.html#aabf6a41dc57cb0ff9c2cfc4e506edf8e',1,'SG::SG_SenseGloveHardware']]]
];
