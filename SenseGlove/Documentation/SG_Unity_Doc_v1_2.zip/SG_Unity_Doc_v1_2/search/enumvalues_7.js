var searchData=
[
  ['objectdependent_1438',['ObjectDependent',['../class_s_g_1_1_s_g___snap_drop_zone.html#a5d70e23b7584b5d31ba0171842fae5f6a3d7bbadb6aaabf7677c8f1af1e3b2df0',1,'SG::SG_SnapDropZone']]]
];
