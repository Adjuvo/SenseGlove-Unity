var searchData=
[
  ['glovedetected_1808',['GloveDetected',['../class_s_g_1_1_s_g___hand_detector.html#a0d3b10f3bd249871fcf57f543bbbdb88',1,'SG::SG_HandDetector']]],
  ['gloveremoved_1809',['GloveRemoved',['../class_s_g_1_1_s_g___hand_detector.html#a7da943bc1212becc50a1ada38eb8cc2d',1,'SG::SG_HandDetector']]]
];
