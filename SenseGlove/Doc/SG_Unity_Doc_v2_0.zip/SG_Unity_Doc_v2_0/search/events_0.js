var searchData=
[
  ['activated_1803',['Activated',['../class_s_g_1_1_s_g___confirm_zone.html#a7248445613b6ec82969c8c6ba32cdc6e',1,'SG::SG_ConfirmZone']]]
];
