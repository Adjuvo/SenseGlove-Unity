var searchData=
[
  ['needscheck_1121',['NeedsCheck',['../class_s_g_core_1_1_calibration_1_1_haptic_glove___cal_check.html#a554b0c1aec4d12a0deb9a69c75cc68cb',1,'SGCore::Calibration::HapticGlove_CalCheck']]],
  ['nextcalibrationstep_1122',['NextCalibrationStep',['../class_s_g_1_1_s_g___calibration_sequence.html#a94a17e4da8783896fe3d11d54d88ae1b',1,'SG::SG_CalibrationSequence']]],
  ['normalizeangle_1123',['NormalizeAngle',['../class_s_g_1_1_util_1_1_s_g___util.html#a869b2fbb01c2e99d1a71117237ecca08',1,'SG.Util.SG_Util.NormalizeAngle(float angle)'],['../class_s_g_1_1_util_1_1_s_g___util.html#a66596f2842f467af8b4981f9a8b2c280',1,'SG.Util.SG_Util.NormalizeAngle(float angle, float minAngle, float maxAngle)']]],
  ['normalizeangles_1124',['NormalizeAngles',['../class_s_g_1_1_util_1_1_s_g___util.html#a2fa40e34c1b418faf01e81ada421165a',1,'SG::Util::SG_Util']]]
];
