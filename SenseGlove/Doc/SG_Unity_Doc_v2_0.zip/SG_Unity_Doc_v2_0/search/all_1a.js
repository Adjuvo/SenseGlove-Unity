var searchData=
[
  ['zerovelocity_885',['ZeroVelocity',['../class_s_g_1_1_s_g___grabable.html#a228364b3057ec2ebd1465b87106c8e9d',1,'SG::SG_Grabable']]],
  ['zoneenabled_886',['zoneEnabled',['../class_s_g_1_1_s_g___confirm_zone.html#a64bc79cfe4fc940ec288fe7bc2907b49',1,'SG::SG_ConfirmZone']]]
];
