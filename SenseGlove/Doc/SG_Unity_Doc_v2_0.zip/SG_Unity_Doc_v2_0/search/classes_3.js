var searchData=
[
  ['glovedetectionargs_867',['GloveDetectionArgs',['../class_s_g_1_1_s_g___hand_detector_1_1_glove_detection_args.html',1,'SG::SG_HandDetector']]]
];
