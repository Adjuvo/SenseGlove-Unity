var searchData=
[
  ['originalrotation_2627',['OriginalRotation',['../class_s_g_1_1_examples_1_1_s_g_ex___rotate_simple.html#a320479941ab6653cc288a5d52d2631b0',1,'SG::Examples::SGEx_RotateSimple']]]
];
