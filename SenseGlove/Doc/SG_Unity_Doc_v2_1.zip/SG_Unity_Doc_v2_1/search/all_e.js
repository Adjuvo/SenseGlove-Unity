var searchData=
[
  ['newcvneeded_456',['newCVNeeded',['../class_s_g_1_1_s_g___haptic_glove.html#adf970ccb0ff3fa4f215fadba07be0886',1,'SG::SG_HapticGlove']]],
  ['newposeneeded_457',['newPoseNeeded',['../class_s_g_1_1_s_g___haptic_glove.html#acd16f3e5656d0db2fbc777167a61245e',1,'SG::SG_HapticGlove']]],
  ['nextcalibrationstep_458',['NextCalibrationStep',['../class_s_g_1_1_s_g___calibration_sequence.html#a94a17e4da8783896fe3d11d54d88ae1b',1,'SG::SG_CalibrationSequence']]],
  ['nextstepkey_459',['nextStepKey',['../class_s_g_1_1_s_g___calibration_sequence.html#ab1597367ca47c5317184e4c9467b277b',1,'SG::SG_CalibrationSequence']]],
  ['nocalibrationerror_460',['NoCalibrationError',['../class_s_g_1_1_s_g___calibration_void.html#aceaa9e502687fc93c81525345095aa0eadf57269234a96b37f3188293662e9654',1,'SG::SG_CalibrationVoid']]],
  ['none_461',['None',['../class_s_g_1_1_s_g___breakable.html#a8750c60bd4c02823169c8886a90a6dfea6adf97f83acf6453d4a6a4b1070f3754',1,'SG::SG_Breakable']]],
  ['normalizeangle_462',['NormalizeAngle',['../class_s_g_1_1_util_1_1_s_g___util.html#a869b2fbb01c2e99d1a71117237ecca08',1,'SG.Util.SG_Util.NormalizeAngle(float angle)'],['../class_s_g_1_1_util_1_1_s_g___util.html#a66596f2842f467af8b4981f9a8b2c280',1,'SG.Util.SG_Util.NormalizeAngle(float angle, float minAngle, float maxAngle)']]],
  ['normalizeangles_463',['NormalizeAngles',['../class_s_g_1_1_util_1_1_s_g___util.html#a2fa40e34c1b418faf01e81ada421165a',1,'SG::Util::SG_Util']]],
  ['normalizedflexion_464',['normalizedFlexion',['../class_s_g_1_1_s_g___hand_pose.html#a2fec9893da63cb5e2b910426c20d2cd5',1,'SG::SG_HandPose']]],
  ['numberofobjects_465',['NumberOfObjects',['../class_s_g_1_1_s_g___drop_zone.html#ae5434d3dc7c383fce392db2eb9873330',1,'SG::SG_DropZone']]]
];
