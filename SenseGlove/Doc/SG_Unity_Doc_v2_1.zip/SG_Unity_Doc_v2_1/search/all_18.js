var searchData=
[
  ['xrdevicefamily_856',['xrDeviceFamily',['../class_s_g_1_1_v_r_1_1_s_g___v_r___rig.html#a749d4a677f2aa88507ffc5f5da494b40',1,'SG::VR::SG_VR_Rig']]],
  ['xrdevicename_857',['xrDeviceName',['../class_s_g_1_1_v_r_1_1_s_g___v_r___rig.html#a7fb235b321740b34f6e8bce8f5895f49',1,'SG::VR::SG_VR_Rig']]]
];
